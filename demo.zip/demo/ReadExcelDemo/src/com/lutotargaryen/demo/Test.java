package com.lutotargaryen.demo;

import java.io.IOException;

import com.lutotargaryen.poi.exception.RepeatCreateObject;
import com.lutotargaryen.poi.readexcel.ReadExcel;

public class Test {
	public static void main(String[] args) {
		try {
			ReadExcel re = ReadExcel.newInstance("com.mysql.jdbc.Driver","jdbc:mysql://127.0.0.1:3306/readexcel?userUnicode=true&characterEncoding=UTF-8");
			int s = re.readExcelToMysql("D://ChoiceInfo.XLS");
			switch (s) {
			case ReadExcel.SUCCESS:
				System.out.println("导入成功");
				break;
			case ReadExcel.COLUMNINCONSISTENCY:
				System.out.println("数据库中列名与excel表不一致");
				break;
			case ReadExcel.DATATYPEERROR:
				System.out.println("excel表中数据类型错误");
				break;
			case ReadExcel.FILETYPEERROR:
				System.out.println("文件类型错误");
				break;
			case ReadExcel.INVALIDFILEPATH:
				System.out.println("无效的文件路径");
				break;
			case ReadExcel.HAVENOTABLE:
				System.out.println("数据库中没有相对应的表");
				break;
			}
		} catch (RepeatCreateObject e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
